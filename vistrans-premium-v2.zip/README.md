# VIS INC Premium V2 Website

This is a custom-coded trucking company website starter package.

## Files
- index.html
- css/styles.css
- js/script.js
- assets/vis-logo.jpg
- assets/truck-1.jpg
- assets/truck-2.jpg
- assets/truck-3.jpg

## Deploy to GitHub Pages
1. Create a new public GitHub repo named `vistrans-website`.
2. Upload all files/folders from this ZIP.
3. Go to Settings > Pages.
4. Source: Deploy from a branch.
5. Branch: main.
6. Folder: /root.
7. Save.
8. Your public link will look like:
   https://YOUR-USERNAME.github.io/vistrans-website/

## Notes
- Truck 2 and Truck 3 are duplicates of the original truck photo. Replace them later with more fleet photos.
- The forms are visual placeholders. They need Formspree, EmailJS, or backend connection before real submissions work.
- Update phone/email/USDOT if needed before final launch.
